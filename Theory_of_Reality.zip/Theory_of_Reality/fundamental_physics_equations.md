# Ultimate Core Physics Sheet (Fundamental Equations of Reality)

---

## 1. Classical Mechanics
**Newton's Laws:**
\[
\vec{F} = m \vec{a}, \quad \vec{F}_{\text{net}} = \frac{d \vec{p}}{dt}, \quad \vec{p} = m \vec{v}
\]

**Universal Gravitation:**
\[
F = G \frac{m_1 m_2}{r^2}
\]

**Conservation Laws:**
\[
E_{\text{total}} = \text{constant}, \quad \vec{p}_{\text{total}} = \text{constant}, \quad \vec{L}_{\text{total}} = \text{constant}
\]

---

## 2. Electromagnetism (Maxwell's Equations)
\[
\nabla \cdot \vec{E} = \frac{\rho}{\varepsilon_0}, \quad \nabla \cdot \vec{B} = 0
\]  
\[
\nabla \times \vec{E} = - \frac{\partial \vec{B}}{\partial t}, \quad 
\nabla \times \vec{B} = \mu_0 \vec{J} + \mu_0 \varepsilon_0 \frac{\partial \vec{E}}{\partial t}
\]

---

## 3. Special Relativity
**Lorentz Transformations:**
\[
t' = \gamma \left(t - \frac{v x}{c^2}\right), \quad x' = \gamma (x - v t), \quad \gamma = \frac{1}{\sqrt{1 - v^2/c^2}}
\]

**Mass-Energy Equivalence:**
\[
E = m c^2
\]

---

## 4. General Relativity
**Einstein Field Equations:**
\[
G_{\mu\nu} + \Lambda g_{\mu\nu} = \frac{8 \pi G}{c^4} T_{\mu\nu}
\]

---

## 5. Quantum Mechanics
**Schrödinger Equation:**
\[
i \hbar \frac{\partial}{\partial t} \psi(\vec{r},t) = \hat{H} \psi(\vec{r},t)
\]

**Heisenberg Uncertainty Principle:**
\[
\Delta x \, \Delta p \ge \frac{\hbar}{2}, \quad \Delta E \, \Delta t \ge \frac{\hbar}{2}
\]

**Commutation Relations:**
\[
[\hat{x}_i, \hat{p}_j] = i \hbar \delta_{ij}
\]

**Dirac Equation (Relativistic QM):**
\[
(i \gamma^\mu \partial_\mu - m)\psi = 0
\]

---

## 6. Quantum Field Theory / Standard Model
**General Lagrangian (Gauge + Fermions + Higgs):**
\[
\mathcal{L} = -\frac{1}{4} F_{\mu\nu} F^{\mu\nu} + \bar{\psi}(i \gamma^\mu D_\mu - m)\psi + |D_\mu \phi|^2 - V(\phi)
\]

**Gauge Symmetries:**
\[
U(1)_\text{EM}, \quad SU(2)_\text{Weak}, \quad SU(3)_\text{Strong}
\]

**Field Strength Tensor:**
\[
F_{\mu\nu} = \partial_\mu A_\nu - \partial_\nu A_\mu + i g [A_\mu, A_\nu]
\]

---

## 7. Thermodynamics
**First Law:**
\[
\Delta U = Q - W
\]

**Second Law (Entropy):**
\[
\Delta S \ge 0
\]

---

## 8. Hypothetical Quantum Gravity (Gravitons)
**Linearized Metric Perturbation:**
\[
g_{\mu\nu} = \eta_{\mu\nu} + h_{\mu\nu}, \quad \Box h_{\mu\nu} = - \frac{16 \pi G}{c^4} T_{\mu\nu}
\]

**Graviton Field Quantization:**
\[
\hat{h}_{\mu\nu}(x) = \sum_{\vec{k},\lambda} \left( \epsilon_{\mu\nu}^\lambda a_{\vec{k},\lambda} e^{i k x} + \epsilon_{\mu\nu}^{\lambda *} a_{\vec{k},\lambda}^\dagger e^{-i k x} \right)
\]

---

## 9. Conservation & Symmetry Principles
**Noether's Theorem (general form):**
\[
\text{Symmetry of Lagrangian} \Rightarrow \text{Conserved Quantity}
\]

**Energy-Momentum Tensor Conservation:**
\[
\partial_\mu T^{\mu\nu} = 0
\]

---

## 10. Summary
These equations represent the **foundational core** of all proven physics:

- **Classical:** Newton + Gravitation + Conservation  
- **EM:** Maxwell  
- **Relativity:** Special + General  
- **Quantum:** Schrödinger + Dirac + Uncertainty + QFT  
- **Thermodynamics:** 1st & 2nd Law  
- **Quantum Gravity (hypothetical):** Gravitons & Metric Perturbation  
- **Symmetries & Conservation:** Noether

This is the **mathematical skeleton** upon which all physical reality is built. ToR, which is the unification of ToE, MToE and ToC, is built apon and unifies these equations.