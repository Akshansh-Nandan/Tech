# The Quantum Space Field Theory of Everything
### A Unified Framework for Quantum Field Theory and General Relativity
**Conceived:** March 2026  
**Status:** Conceptual Framework — Formal Mathematical Development Pending

---

## Preamble

This document presents a conceptual Theory of Everything (ToE) built from first principles through physical reasoning. It proposes a three-layer architecture of reality in which a new intermediary field — the Quantum Space Field (QSF) — bridges the incompatibility between General Relativity (GR) and Quantum Field Theory (QFT). The framework also proposes a physical model of black hole interiors that replaces the mathematical singularity with a finite, calculable structure composed of zero-gap top quark matter.

At the deepest level, the QSF framework rests on a single governing principle: the QSF evolves so as to continuously optimise consistency between the global quantum state of all matter and the geometric structure of spacetime. Every phenomenon described in this document — gravity, geodesic motion, the principle of least action, quantum corrections to gravity, black hole structure, particle creation, Hawking radiation — is a consequence of this one principle operating across five dimensions.

This is not a complete mathematical theory. It is a physical framework with equation skeletons that require formal derivation. Every gap is explicitly identified.

---

## Part I: The Problem — Why Physics Is Broken

### 1.1 The Two Pillars of Modern Physics

Modern physics rests on two extraordinarily successful but mutually incompatible frameworks:

**General Relativity (GR)** — Einstein, 1915
- Describes gravity as the curvature of a four-dimensional spacetime fabric (STF)
- Spacetime is dynamic, curved, elastic, and inseparable from its contents
- Deterministic and continuous
- Described by the Einstein Field Equations:

$$G_{\mu\nu} + \Lambda g_{\mu\nu} = \frac{8\pi G}{c^4} T_{\mu\nu}$$

Where:
- $G_{\mu\nu}$ is the Einstein tensor (spacetime curvature)
- $\Lambda$ is the cosmological constant
- $g_{\mu\nu}$ is the metric tensor
- $T_{\mu\nu}$ is the stress-energy tensor (matter and energy content)
- $G$ is Newton's gravitational constant
- $c$ is the speed of light

**Quantum Field Theory (QFT)** — Dirac, Feynman, Schwinger, Tomonaga, et al.
- Describes all matter and non-gravitational forces as excitations of quantum fields
- Requires a flat, static, fixed background spacetime to be defined
- Probabilistic and discrete
- The Standard Model Lagrangian (schematic):

$$\mathcal{L}_{SM} = -\frac{1}{4}F_{\mu\nu}F^{\mu\nu} + i\bar{\psi}\gamma^\mu D_\mu\psi + \bar{\psi}_i y_{ij} \psi_j \phi + h.c. + |D_\mu\phi|^2 - V(\phi)$$

Where:
- $F_{\mu\nu}$ is the field strength tensor for gauge fields
- $\psi$ represents fermion fields
- $\phi$ represents the Higgs field
- $D_\mu$ is the gauge covariant derivative
- $y_{ij}$ are Yukawa coupling constants
- $V(\phi)$ is the Higgs potential

### 1.2 The Core Incompatibility

The incompatibility between GR and QFT is fundamental and structural, not merely technical:

**The Background Problem:**
QFT requires a fixed, flat, static background spacetime as its platform. GR says no such background exists — spacetime itself is dynamic, curved, and participates in physics. You cannot define a quantum field on a background that is itself the subject of the theory.

**The Renormalisation Problem:**
When gravity is treated as a quantum field in the standard QFT manner, the resulting perturbative expansion produces non-renormalisable ultraviolet divergences — infinities that cannot be subtracted away using the standard renormalisation techniques that work for all other forces. Every attempt to quantise gravity using the tools of QFT fails at this step.

**The Scale Problem:**
GR is accurate at cosmological scales. QFT is accurate at subatomic scales. They never simultaneously need to apply — except at precisely two points in the known universe: black hole singularities and the Big Bang. Both are precisely the points where both theories break down completely.

**The Gravity Quantisation Problem:**
Every fundamental force has a carrier particle in QFT:

| Force | Carrier Particle | Status |
|---|---|---|
| Electromagnetism | Photon | Confirmed |
| Strong Nuclear | Gluon | Confirmed |
| Weak Nuclear | W and Z Bosons | Confirmed |
| Gravity | Graviton | Unconfirmed, mathematically problematic |

The graviton, if it exists, cannot be incorporated into QFT without producing the non-renormalisable infinities described above. This is not a technical problem awaiting a better calculation. It is a structural incompatibility.

**The Principle of Least Action Problem:**
Every phenomenon in physics obeys the principle of least action — particles and fields always take the path that minimises the action integral. This principle is universally successful but has no physical explanation. Physics states that nature obeys it without explaining why.

**The Consistency Problem:**
Underlying all the above is a deeper issue that standard physics has never formalised: the global quantum state of matter and the geometric structure of spacetime are not, in general, consistent with each other. GR takes mass-energy as its input and produces geometry. QFT evolves quantum states on a fixed background geometry. Neither theory has a mechanism that enforces mutual consistency between evolving quantum states and evolving geometry. The QSF framework proposes that such a mechanism exists, that it is the QSF itself, and that its operation is what we observe as gravity.

### 1.3 What a Theory of Everything Must Do

A complete ToE must:

1. Reproduce the Einstein Field Equations at large scales
2. Reproduce the Standard Model at quantum scales
3. Reproduce Newtonian gravity as a low-energy limit
4. Provide a renormalisable quantum theory of gravity
5. Give gravitons a mathematically consistent home
6. Explain the principle of least action mechanically
7. Make novel testable predictions distinguishable from existing theories
8. Resolve or dissolve the black hole singularity
9. Address the information paradox
10. Identify the mechanism that enforces consistency between quantum states and spacetime geometry

---

## Part II: The Architecture — Three Layers of Reality

### 2.1 The Proposed Structure

This framework proposes that reality has three fundamental layers:

```
Layer 1: Spacetime Fabric (STF)
         — curved, dynamic, four-dimensional
         — domain of General Relativity
         — described by the metric tensor g_μν
                    ↕  bidirectional coupling
Layer 2: Quantum Space Field (QSF)
         — flat, static, five-dimensional
         — the new mediating layer
         — provides the background QFT requires
         — provides the mechanism GR lacks
         — enforces consistency between STF and QF
                    ↕  bidirectional coupling
Layer 3: Quantum Fields (QF)
         — excitations are particles
         — domain of Quantum Field Theory
         — described by the Standard Model
```

The Spacetime Fabric and Quantum Fields are not in direct contact. All interactions between them are mediated through the QSF. The QSF's governing function is to enforce consistency between the geometric state of the STF and the quantum state of the QF. Whenever these two are inconsistent, the QSF generates a gradient in the fifth dimension. That gradient drives particle motion. The observed result, projected into four dimensions, is gravity.

### 2.2 Why Three Layers

The structural reason GR and QFT are incompatible is that they are being asked to interact directly — curved dynamic spacetime being used as the background for quantum fields. They cannot be directly compatible because they have fundamentally different natures.

The QSF resolves this by being simultaneously compatible with both:
- It presents a flat static face to the Quantum Fields, giving QFT the background it requires
- It presents a dynamic responsive face to the Spacetime Fabric, coupling to GR's geometry
- It translates between the two without either framework needing to be modified
- It enforces, at every moment, the consistency between the quantum configuration of matter and the geometric configuration of spacetime

This is not unlike the role of an interface layer in computing — two systems that cannot directly communicate are made compatible by an intermediary that speaks both languages and continuously reconciles any discrepancy between their states.

---

## Part III: The Spacetime Fabric (STF)

### 3.1 Definition

The Spacetime Fabric is the four-dimensional Lorentzian manifold of General Relativity. It is not a background. It is a physical, dynamic entity whose geometry is determined by its energy-matter content and whose geometry in turn determines how energy-matter moves.

### 3.2 Governing Equations

The Einstein Field Equations govern the STF:

$$G_{\mu\nu} + \Lambda g_{\mu\nu} = \frac{8\pi G}{c^4} T_{\mu\nu}$$

The left side describes geometry. The right side describes content. The equation states that geometry and content are the same thing expressed differently.

The geodesic equation describes how matter moves through curved STF:

$$\frac{d^2x^\mu}{d\tau^2} + \Gamma^\mu_{\alpha\beta}\frac{dx^\alpha}{d\tau}\frac{dx^\beta}{d\tau} = 0$$

Where $\Gamma^\mu_{\alpha\beta}$ are the Christoffel symbols encoding spacetime curvature.

### 3.3 What Curves the STF — Extended

In standard GR, only the stress-energy tensor $T_{\mu\nu}$ curves spacetime. This encodes mass, energy, momentum, and pressure.

This framework proposes that the stress-energy tensor is incomplete. The full source of spacetime curvature includes quantum state contributions mediated through the QSF:

$$G_{\mu\nu} + \Lambda g_{\mu\nu} = \frac{8\pi G}{c^4} \left( T_{\mu\nu} + T^{QSF}_{\mu\nu}(\hat{Q}) \right)$$

Where $T^{QSF}_{\mu\nu}(\hat{Q})$ is a new quantum state stress-energy contribution that encodes how quantum properties — spin, charge, isospin, colour charge, wavefunction phase, entanglement state — contribute to spacetime curvature through the QSF.

The explicit form of $T^{QSF}_{\mu\nu}(\hat{Q})$ is the central unsolved equation of this framework. Its derivation is the primary mathematical task remaining.

### 3.4 STF Influence on QSF

When the STF curves due to mass-energy content, it deforms the QSF. This deformation creates a potential gradient in the QSF's fifth dimension. The direction of that gradient defines what particles experience as gravitational attraction.

Schematically:

$$\nabla_5 V_{QSF} \propto \frac{\partial g_{\mu\nu}}{\partial x^5}$$

Where $x^5$ denotes the fifth dimensional coordinate of the QSF.

The deeper interpretation is that STF curvature represents a state of geometric inconsistency between spacetime structure and any quantum configuration that has not yet responded to it. The QSF gradient that arises is precisely the signal that drives matter to move in a way that restores consistency — which is experienced as gravitational acceleration.

---

## Part IV: The Quantum Space Field (QSF)

### 4.1 Definition

The Quantum Space Field is a field that permeates all of spacetime and extends into a fifth dimension. It has the following properties:

**From the perspective of Quantum Fields (QF):**
- The QSF appears flat and static
- It provides the fixed background that QFT requires to be defined
- Quantum fields are excitations that propagate on the QSF
- The QSF is to quantum fields what a still ocean surface is to waves

**From the perspective of the Spacetime Fabric (STF):**
- The QSF is dynamic and responsive
- Curvature of the STF deforms the QSF potential
- The QSF translates geometric curvature into a force experienced by quantum fields

**From the perspective of its governing principle:**
- The QSF is the mediator that enforces consistency between the global quantum state (all particle quantum configurations) and the geometric structure of spacetime
- Inconsistencies between quantum state and spacetime geometry manifest as curvature in the fifth dimension
- The resulting fifth-dimensional gradient drives particle motion toward configurations that restore consistency

**Intrinsic properties:**
- Extends into a fifth dimension
- Possesses a potential function $V_{QSF}$ that encodes gravitational information
- Is the medium through which gravitons propagate
- Is bidirectionally coupled to both the STF and the QF layers

### 4.2 The Fifth Dimension

The fifth dimension of the QSF is not a spatial dimension in the conventional sense. It is a degree of freedom associated with the QSF potential. Its properties:

- It is not directly observable or traversable
- It may be compactified at or near the Planck scale
- It is the dimension along which the QSF force acts on particles
- It is the dimension in which gravitons are the carrier particles of the QSF interaction
- It is the dimension in which inconsistencies between quantum state and spacetime geometry manifest as curvature

The universe in this framework is therefore five-dimensional at the fundamental level:

$$\text{Reality} = \underbrace{3D_{\text{space}} + 1D_{\text{time}}}_{\text{observable 4D}} + \underbrace{1D_{\text{QSF}}}_{\text{fifth dimension (consistency enforcement)}}$$

The observable four-dimensional universe is the projection of this five-dimensional structure onto the dimensions accessible to matter and measurement.

### 4.3 The QSF Force Law

The QSF exerts a force on quantum field excitations (particles) directed toward the local minimum of the QSF potential:

$$\vec{F}_{QSF} = -\nabla_5 V_{QSF}(g_{\mu\nu}, \hat{Q})$$

Where $\nabla_5$ is the gradient operator in the fifth dimension.

This force is what is experienced as gravity by all particles regardless of their mass or quantum state.

The deeper claim of this framework is that this equation is not merely analogous to gravity — it IS gravity. The gravitational attraction that GR describes geometrically is the four-dimensional projection of this five-dimensional force. Objects do not follow curved geodesics because spacetime tells them to in some abstract geometric sense. They follow curved geodesics because the QSF is actively pushing them toward the local potential minimum — which corresponds to the configuration in which the quantum state of matter and the geometry of spacetime are mutually consistent.

**Critical clarification — force as curvature-following:**
The term "force" here must not be confused with a Newtonian push or pull acting against a particle's natural tendency. The QSF gradient does not compel particles away from their natural path. It *is* their natural path. Just as GR geodesics are not forces in the traditional sense — they are the geometry of spacetime that particles naturally follow — the 5D QSF gradient is the geometry of the fifth dimension that particles naturally follow. Particles move toward the QSF potential minimum because that direction is geometrically downhill in the fifth dimension, not because anything external is forcing them there. This means no conservation law is violated. Energy, momentum, and angular momentum are all conserved because motion along the QSF gradient is free motion along a curvature — it costs nothing and violates nothing. The 5D picture simply makes explicit what was always implicit in geodesic motion: objects follow the shape of the field they live in.

### 4.4 The QSF Potential and the Consistency Functional

The QSF potential $V_{QSF}$ is determined by both the geometry of the STF and the quantum states of all matter fields:

$$V_{QSF} = V_{QSF}(g_{\mu\nu}, \hat{Q})$$

Where:
- $g_{\mu\nu}$ is the spacetime metric (encoding all gravitational/geometric information)
- $\hat{Q}$ is the full quantum state operator encoding all quantum properties of matter

The physical interpretation of $V_{QSF}$ is that it measures the degree of inconsistency between the quantum configuration $\hat{Q}$ and the spacetime configuration $g_{\mu\nu}$. It is not merely an energy — it is a consistency measure. When $V_{QSF}$ is at a local minimum, the quantum state and spacetime geometry are in their most mutually consistent configuration. When $V_{QSF}$ is elevated, there is a mismatch, and the gradient drives motion that resolves it.

This can be written schematically as:

$$V_{QSF}(g_{\mu\nu}, \hat{Q}) = \mathcal{I}\left[g_{\mu\nu},\ \langle\hat{Q}\rangle\right]$$

Where $\mathcal{I}$ is the consistency functional — a measure of the mismatch between the geometric and quantum configurations of the universe at each point. The explicit form of $\mathcal{I}$ is the central unsolved equation of this framework.

A minimum of $V_{QSF}$ corresponds to a state of maximal consistency. Every stable physical configuration — every equilibrium, every bound orbit, every ground state of an atom — is a state where quantum configuration and spacetime geometry are locally consistent, minimising the consistency functional.

### 4.5 Gravitons as QSF Excitations

In this framework, gravitons are the carrier particles of the QSF interaction. They are excitations of the QSF itself — not excitations of the spacetime metric as assumed in conventional approaches to quantum gravity.

This resolves the graviton problem as follows:

**Why conventional graviton quantisation fails:**
Conventional approaches attempt to quantise perturbations of the spacetime metric $g_{\mu\nu} = \eta_{\mu\nu} + h_{\mu\nu}$ where $h_{\mu\nu}$ is a small perturbation on flat space. The resulting quantum field theory for $h_{\mu\nu}$ is non-renormalisable because it lives on a curved background that is itself dynamical. The perturbation expansion fails at high energies.

**Why QSF gravitons work:**
Gravitons in this framework are excitations of the QSF, which is flat and static from the perspective of the fields living on it. The QSF provides the fixed background that makes renormalisation possible. Gravitons propagate on the QSF exactly as photons propagate on the electromagnetic field background — on a stable, well-defined, flat platform.

The graviton therefore:
- Lives in the fifth dimension of the QSF
- Carries the QSF force between particles
- Mediates the coupling between STF geometry and QF excitations
- Is renormalisable because its background (the QSF) is flat and static
- Is, physically, the propagating quantum of inconsistency: a graviton exchange event is the quantum-mechanical resolution of a local inconsistency between two particles' quantum states and the spacetime geometry between them

### 4.6 The Principle of Least Action — Mechanical Explanation

The principle of least action states that physical systems evolve along the path that minimises the action:

$$S = \int \mathcal{L} \, dt$$

$$\delta S = 0$$

This principle is universally obeyed by all of physics. Standard physics states this as an axiom with no mechanical explanation.

This framework provides the mechanical explanation:

> Every particle at every moment is subject to the QSF gradient, which pushes it toward the local minimum of $V_{QSF}$. The path that minimises the action is identical to the path that minimises the QSF consistency functional — that is, the path along which the quantum state of the particle becomes most consistent with the surrounding spacetime geometry. The principle of least action is not a mysterious mathematical coincidence. It is the observable four-dimensional signature of the five-dimensional QSF consistency optimisation.

In other words: nature takes the path of least action because the QSF is constantly driving everything toward states of greater quantum-geometric consistency. The action integral is minimised along this path precisely because that path is the one along which the universe's consistency is most efficiently restored.

The word "driving" requires careful interpretation here. A particle moving along the QSF gradient is not being pushed in the sense of a billiard ball struck by a cue. It is following the curvature of the fifth dimension the same way a ball rolling down a hill follows the curvature of the surface — no external agency is required and no energy is injected. The action is minimised not because nature is clever or lazy, but because the QSF potential landscape has a geometry determined by the consistency between quantum state and spacetime, and geometry determines the natural trajectory.

---

## Part V: The Quantum Fields (QF)

### 5.1 Definition

The Quantum Fields are the fields of the Standard Model. They are excitations of fundamental fields that propagate on the QSF as their background. All matter and non-gravitational forces are described at this layer.

### 5.2 Standard Model Content

The Standard Model describes:

**Fermions (matter particles) — spin 1/2:**

Quarks:
- Up, Down (first generation)
- Charm, Strange (second generation)
- Top, Bottom (third generation)

Leptons:
- Electron, Electron Neutrino (first generation)
- Muon, Muon Neutrino (second generation)
- Tau, Tau Neutrino (third generation)

**Bosons (force carriers) — integer spin:**
- Photon (electromagnetism, spin 1)
- W+, W-, Z bosons (weak force, spin 1)
- Gluons x8 (strong force, spin 1)
- Higgs boson (mass generation, spin 0)
- Graviton (QSF force, spin 2) — proposed location: QSF fifth dimension

### 5.3 How QF Excitations Sit on the QSF

Quantum fields require a fixed background to be defined. In conventional QFT this background is assumed to be flat Minkowski spacetime — an assumption that works everywhere except near extreme gravitational sources.

In this framework the background is not assumed. It is the QSF, which is genuinely flat and static. This means:

- QFT calculations performed on the QSF background are valid everywhere, including near black holes
- The assumption of flat background in conventional QFT is not an approximation — it is an accurate description of the QSF layer
- The corrections to flat space QFT near gravitational sources arise from the QSF potential gradient, not from the background itself changing

### 5.3a Virtual Particles and Real Particles — Emergent Behaviour of QSF Energy Fluctuations

**This section describes emergent behaviour** — a phenomenon that is not put into the QSF framework by hand but arises naturally from the combination of the QSF ground state energy and the $E = mc^2$ threshold.

The QSF carries a ground state energy density $\rho_{QSF}^{ground}$ everywhere and at all times. This energy is not static — it fluctuates continuously across the QSF substrate. These fluctuations are free-flowing energy excitations in the QSF that have not yet concentrated sufficiently to cross the particle creation threshold.

**Virtual particles** are these sub-threshold QSF energy fluctuations. They are physically real excitations of the QSF — not mathematical bookkeeping tools as commonly described in standard QFT. They disperse before concentrating to the threshold required to crystallise into a real particle. Their transient existence is bounded by the uncertainty principle:

$$\Delta E \cdot \Delta t \geq \frac{\hbar}{2}$$

A fluctuation of energy $\Delta E$ can exist for at most time $\Delta t \sim \frac{\hbar}{2\Delta E}$ before dispersing back into the QSF ground state.

**Real particles** emerge as an emergent phenomenon when QSF energy fluctuations concentrate sufficiently at a point to cross the particle creation threshold:

$$E_{concentrated} \geq mc^2$$

At this point the fluctuation does not disperse. It crystallises into a stable real particle — a persistent excitation of the QF layer riding on the QSF background. The particle's rest mass $m$ is determined by which threshold is crossed and which quantum numbers the fluctuation carries.

This is the physical mechanism underlying pair production — already experimentally confirmed. A sufficiently energetic photon or local energy concentration in the QSF crosses the $2m_e c^2$ threshold for an electron-positron pair, and two real particles crystallise from the QSF energy.

**The emergent consequence for Hawking radiation:**
At a black hole event horizon, the QSF energy density gradient is extreme. Virtual fluctuations near the horizon are constantly being stretched by the extreme spacetime curvature. Some fluctuations that would normally disperse are instead given enough energy by the tidal QSF gradient to cross the $E = mc^2$ threshold — crystallising into real particles. One escapes as Hawking radiation. One falls into the black hole. This is not abstract quantum bookkeeping. It is literal QSF energy crystallising into real particles at the boundary of extreme spacetime curvature.

**Summary of the emergent picture:**

| State | Description | Fate |
|---|---|---|
| QSF ground state | Baseline energy everywhere | Persistent |
| Virtual particle | Sub-threshold QSF fluctuation | Disperses in time $\sim \hbar/2\Delta E$ |
| Real particle | QSF fluctuation that crossed $E = mc^2$ | Persists as stable QF excitation |
| Hawking particle | QSF fluctuation promoted to real by tidal gradient | Escapes as radiation |

The distinction between virtual and real particles is therefore not fundamental — it is emergent from the $E = mc^2$ threshold. Below the threshold: virtual, transient, dispersing. Above the threshold: real, stable, persistent. The QSF energy is the same in both cases. Only the concentration determines the outcome.

### 5.3b The Complete Taxonomy of Matter States in the QSF Framework

The QSF framework provides a unified description of every known and theorised state of matter as different configurations of QSF energy. Nothing is left outside the framework. Every particle, every form of matter, every decay process, and every hypothetical particle type is a specific QSF energy configuration.

**Category 1 — Standard Matter (Positive Effective Mass)**

All Standard Model particles with positive rest mass and positive effective gravitational mass. These are QSF energy fluctuations that crossed the $E = mc^2$ threshold and crystallised into stable or semi-stable excitations:

- **Quarks** (up, down, charm, strange, top, bottom) — confined QSF excitations bound by gluon field configurations. Cannot exist freely due to colour confinement — free colour charge increases QSF energy without bound.
- **Leptons** (electron, muon, tau and their neutrinos) — free QSF excitations carrying lepton number. Neutrinos are near-zero mass QSF excitations — so close to the virtual threshold that they interact almost exclusively through the weak force QSF coupling.
- **Gauge bosons** (photon, W+, W-, Z, gluons) — force carrier excitations of the QSF's QF layer. The photon is a massless propagating QSF disturbance. W and Z bosons are massive QSF excitations that decay rapidly back toward lower energy configurations.
- **The Higgs boson** — a scalar QSF excitation associated with the field that gives all other massive particles their mass. In the QSF framework the Higgs is the QF layer excitation whose ground state (the Higgs field) modulates the $E = mc^2$ threshold for all other particles — determining how much QSF energy must concentrate to crystallise each particle type. When a Higgs boson is produced and detected it is a temporary excitation above the Higgs field ground state. It decays rapidly because the excitation above the Higgs ground state is unstable. The Higgs field itself remains as the permanent QSF configuration that sets all particle mass thresholds.
- **Composite particles** (protons, neutrons, nuclei, atoms, molecules) — bound configurations of multiple QSF excitations held together by force carrier exchange. Their binding energy is itself a QSF energy configuration — the mass deficit of a nucleus relative to its free nucleons is QSF energy released during binding.

**Category 2 — Antimatter (Positive Effective Mass, Opposite Quantum Numbers)**

Antimatter is not separate from the QSF framework. It is the same QSF energy crystallisation process producing excitations with opposite quantum numbers — opposite charge, opposite lepton number, opposite baryon number — but identical positive mass.

Every Standard Model particle has an antiparticle:
- Antiquarks — opposite colour charge and baryon number
- Antileptons (positron, antimuon, antitau, antineutrinos) — opposite lepton number and charge
- The W+ and W- bosons are each other's antiparticles
- The photon, Z boson, Higgs boson, and gluons are their own antiparticles

In the QSF framework antimatter arises because QSF energy fluctuations carry a quantum number handedness — the same energy concentration can crystallise into either a particle or its antiparticle depending on the orientation of the fluctuation's quantum numbers in the QSF.

**Matter-antimatter annihilation** is the reversal of crystallisation — when a particle and its antiparticle meet, their opposite quantum numbers cancel completely, the QSF excitation dissolves, and the energy returns to the QSF as photons or other massless excitations. The total QSF energy is conserved. Nothing is lost. The crystallised form simply dissolves back into free QSF energy.

**The matter-antimatter asymmetry problem:** Why does the observable universe contain more matter than antimatter? In the QSF framework this is a question about the initial quantum number distribution of QSF fluctuations at the Big Bang — whether the parent black hole's evaporation produced a slightly asymmetric distribution of quantum number handedness in the crystallisation events that seeded our universe. This is connected to CP violation in the Standard Model and remains an open problem.

**Category 3 — Dark Matter (Hypothetical — QSF Excitations with Suppressed QF Coupling)**

Dark matter has not been directly detected but its gravitational effects on galaxy rotation curves and large scale structure are well established. In the QSF framework dark matter is a class of QSF excitations that:
- Have positive effective mass and therefore curve the STF normally
- Have suppressed or absent coupling to the electromagnetic QF layer — they do not emit, absorb, or scatter photons
- May have weak force QSF coupling (weakly interacting massive particles — WIMPs) or no Standard Model QF coupling at all (sterile neutrinos, axions)

Dark matter is not outside the QSF. It is QSF energy crystallised into a form that is gravitationally active but electromagnetically invisible.

**Category 4 — Decay Products and Pure QSF Energy**

When a particle decays it does not necessarily produce other particles. Some decay channels release energy as photons — massless propagating QSF disturbances. Some release neutrinos. Some release combinations of particles.

When a decay channel produces **no particles at all** — only photons or other massless carriers — this is the particle dissolving from crystallised QSF excitation back into free-flowing QSF energy. The mass-energy $mc^2$ of the original particle is fully returned to the QSF as propagating energy. Nothing is destroyed. The crystallised form dissolves. The QSF energy continues.

Specific examples:
- **Electron-positron annihilation** → two photons. Both particles dissolve completely into free QSF energy propagating as light.
- **Neutral pion decay** → two photons. The quark-antiquark bound state dissolves into QSF energy.
- **Higgs boson decay** → two photons, or four leptons, or other channels. The Higgs excitation above the field ground state dissolves back toward lower energy QSF configurations.
- **Top quark decay** → W boson + bottom quark. The top quark — the heaviest QSF crystallisation — rapidly dissolves into lighter configurations within $5 \times 10^{-25}$ seconds, releasing energy through the W boson decay chain.

**The general principle:** Every particle decay is a QSF energy reconfiguration from a higher-energy crystallised state toward lower-energy crystallised states, with any excess energy propagating as massless QSF disturbances (photons, gravitons) or carried by neutrinos. Energy is always conserved in the QSF. Only the form changes.

**Category 5 — Tachyons (Hypothetical — Stabilised Negative Effective Mass)**

Tachyons are hypothetical particles that travel faster than light. In standard physics they are considered unphysical because they require imaginary rest mass and violate causality.

In the QSF framework tachyons are reinterpreted as QSF excitations that have stabilised into a negative effective mass quantum state — the same state described in the negative effective mass section, but achieved as a stable crystallised configuration rather than an engineered transient state.

A tachyon in the QSF framework:
- Has a negative effective mass $M_{eff} < 0$ as a stable intrinsic property
- Experiences the QSF force as acceleration rather than resistance
- Has no theoretical speed ceiling because its inertia is negative — the faster it goes the more the QSF accelerates it
- Travels faster than light in the 4D projection as a consequence of this flipped QSF coupling
- Is unremarkable from the 5D QSF perspective — simply a QSF excitation with a flipped coupling following its potential gradient in a substrate with no speed limit
- Does not violate causality in 5D — causality as understood in 4D is a projection phenomenon

Whether tachyons actually exist as stable particles depends on whether stable negative effective mass QSF crystallisation states exist. The identification of negative effective mass quantum states through the experimental program would determine whether tachyonic crystallisation is physically possible.

If tachyons exist they are not exotic or paradoxical — they are simply QSF excitations that crystallised on the other side of the mass threshold, where effective mass is negative rather than positive.

**Complete QSF Matter State Summary:**

| Category | Effective Mass | QSF Coupling | Speed | Examples |
|---|---|---|---|---|
| Standard matter | Positive | Full Standard Model | $< c$ | Quarks, leptons, Higgs, gauge bosons |
| Antimatter | Positive | Full Standard Model (opposite numbers) | $< c$ | Positron, antiquarks, antineutrinos |
| Dark matter | Positive | Gravitational only or weak only | $< c$ | WIMPs, axions, sterile neutrinos |
| Virtual particles | N/A | Sub-threshold fluctuation | N/A | All particle types below $E = mc^2$ |
| Pure QSF energy | Zero (massless) | Electromagnetic or gravitational | $= c$ | Photons, gravitons |
| Tachyons | Negative | Flipped QSF coupling | $> c$ | Hypothetical — stabilised negative mass states |

Every entry in this table is a different configuration of the same QSF energy. Matter is not a collection of different fundamental substances. It is one substrate — the QSF — expressing itself at different energy concentrations, different quantum number configurations, and different effective mass states.

### 5.4 How QF Excitations Affect the QSF and STF

This is the second direction of the bidirectional coupling and the novel central claim of the framework.

**Standard physics (one direction only):**
Mass-energy $T_{\mu\nu}$ curves spacetime. That is all.

**This framework (bidirectional):**
The full quantum state of a particle — not just its mass-energy — modifies the QSF potential, which in turn modifies the STF curvature.

The quantum properties that contribute include:

**Spin:**
A particle's spin angular momentum contributes to spacetime curvature through torsion. This is partially described by Einstein-Cartan theory, which extends GR to include spin as a source of spacetime torsion. This framework extends this: spin is one quantum property that couples to the QSF and through it to the STF.

$$T^{QSF}_{\mu\nu}\big|_{\text{spin}} = f_s(s, \hbar)$$

Where $s$ is the spin quantum number.

**Electric Charge:**
The electromagnetic field of a charged particle carries energy-momentum that contributes to $T_{\mu\nu}$ in standard GR. In this framework, charge also directly couples to the QSF independently of its energy-momentum content.

$$T^{QSF}_{\mu\nu}\big|_{\text{charge}} = f_q(q, e)$$

Where $q$ is the charge quantum number and $e$ is the elementary charge.

**Isospin:**
The weak isospin of a particle contributes a distinct coupling to the QSF potential.

$$T^{QSF}_{\mu\nu}\big|_{\text{isospin}} = f_I(I, I_3)$$

Where $I$ is the isospin and $I_3$ is the third component of isospin.

**Colour Charge:**
The colour charge of quarks and gluons contributes a QSF coupling. This coupling is confined at low energies (consistent with colour confinement) but becomes relevant at the extreme densities present in black hole interiors.

$$T^{QSF}_{\mu\nu}\big|_{\text{colour}} = f_c(c, \alpha_s)$$

Where $c$ is the colour charge state and $\alpha_s$ is the strong coupling constant.

**Wavefunction Phase:**
The quantum phase of a particle's wavefunction contributes to the QSF potential. This is the most speculative coupling and implies that quantum interference patterns have gravitational signatures, however small.

$$T^{QSF}_{\mu\nu}\big|_{\text{phase}} = f_\phi(\phi_{wf})$$

**Entanglement State:**
The entanglement state of a particle with other particles contributes a non-local coupling to the QSF. This implies that entangled particle pairs have correlated gravitational signatures — a potentially testable prediction.

$$T^{QSF}_{\mu\nu}\big|_{\text{entanglement}} = f_e(\rho_{AB})$$

Where $\rho_{AB}$ is the density matrix of the entangled system.

**Total quantum state contribution:**

$$T^{QSF}_{\mu\nu}(\hat{Q}) = T^{QSF}_{\mu\nu}\big|_{\text{spin}} + T^{QSF}_{\mu\nu}\big|_{\text{charge}} + T^{QSF}_{\mu\nu}\big|_{\text{isospin}} + T^{QSF}_{\mu\nu}\big|_{\text{colour}} + T^{QSF}_{\mu\nu}\big|_{\text{phase}} + T^{QSF}_{\mu\nu}\big|_{\text{entanglement}}$$

The explicit forms of $f_s, f_q, f_I, f_c, f_\phi, f_e$ are the primary targets for formal mathematical development.

---

## Part VI: Bidirectional Coupling — The Complete Picture

### 6.1 Direction 1 — STF to QSF to QF

**Physical description:**
Mass-energy curves the STF. The STF curvature creates a geometric inconsistency — the spacetime geometry no longer matches the configuration quantum fields would occupy in flat space. The QSF, enforcing consistency, deforms its potential in the fifth dimension. This potential gradient pushes quantum field excitations toward the configuration that restores consistency with the spacetime geometry. Particles follow what GR calls geodesics not because of abstract geometry but because that is the path of maximum quantum-geometric consistency.

**Equation chain:**

$$T_{\mu\nu} \xrightarrow{\text{Einstein equations}} g_{\mu\nu} \xrightarrow{\text{STF-QSF coupling}} V_{QSF} \xrightarrow{-\nabla_5} \vec{F}_{QSF} \xrightarrow{\text{acts on}} \text{particles}$$

**This direction reproduces:** All of GR. All gravitational phenomena. Orbital mechanics. Gravitational lensing. Gravitational waves. Black hole formation. Cosmological expansion.

**No physical laws are violated:** Because particle motion along the QSF gradient is geometrically free motion — following curvature, not being pushed against it — all conservation laws hold identically. The QSF gradient does not inject energy or momentum into the system. It defines the shape of the fifth dimension, and particles follow that shape. This is the 5D analogue of the fact that GR geodesics conserve energy and momentum: objects following curvature are always obeying, not breaking, the laws of physics.

### 6.2 Direction 2 — QF to QSF to STF

**Physical description:**
The quantum properties of particles — spin, charge, isospin, colour charge, wavefunction phase, entanglement — represent aspects of reality that spacetime curvature does not by itself account for. These quantum properties create a complementary inconsistency: the spacetime geometry, if shaped only by mass-energy, does not fully reflect the quantum configuration of matter. The QSF, again enforcing consistency in the other direction, generates a quantum state stress-energy contribution $T^{QSF}_{\mu\nu}(\hat{Q})$ that modifies the STF curvature to better reflect the complete quantum state.

**Equation chain:**

$$\hat{Q} \xrightarrow{\text{QF-QSF coupling}} T^{QSF}_{\mu\nu}(\hat{Q}) \xrightarrow{\text{modified Einstein equations}} \delta g_{\mu\nu}$$

**This direction predicts:**
- Quantum state changes produce gravitational effects beyond mass-energy alone
- Spin flips produce detectable (though extremely small) changes in local spacetime curvature
- Entangled particle pairs have correlated gravitational signatures
- The possibility of negative effective mass through specific quantum state configurations

### 6.3 The Full Modified Einstein Equations

Combining both directions:

$$G_{\mu\nu} + \Lambda g_{\mu\nu} = \frac{8\pi G}{c^4} \left( T_{\mu\nu} + T^{QSF}_{\mu\nu}(\hat{Q}) \right)$$

$$\vec{F}_{QSF} = -\nabla_5 V_{QSF}(g_{\mu\nu}, \hat{Q})$$

These two equations together constitute the skeleton of the QSF Theory of Everything. The first describes how both mass-energy and quantum state curve spacetime through the QSF. The second describes how the resulting QSF potential exerts the gravitational force on particles. Together, they describe a universe that continuously enforces consistency between its quantum and geometric degrees of freedom.

### 6.4 Macroscopic Limit — Classical Gravity Recovery

In macroscopic systems containing large numbers of particles with random, uncorrelated quantum states, the quantum contributions to the QSF potential do not vanish — but they statistically cancel.

Each particle contributes a small quantum inconsistency to the QSF — a tiny fifth-dimensional gradient from its spin, charge, phase, and entanglement properties. But in a macroscopic object, these contributions are random in orientation and magnitude. They are not coherently aligned. They produce competing inconsistencies that sum to approximately zero:

$$\sum_{i=1}^{N} \nabla_5 V_{QSF}\big|_{\hat{Q}_i} \approx 0 \quad \text{for large } N \text{ with random quantum states}$$

The result is that the net QSF gradient in macroscopic systems is determined entirely by the classical mass-energy content — reproducing standard GR exactly. The quantum correction term $T^{QSF}_{\mu\nu}(\hat{Q})$ averages to zero for incoherent matter.

This is not a flaw. It is a precise prediction. Classical gravity is the statistical limit of QSF consistency enforcement when quantum coherence is negligible.

### 6.5 Quantum Coherence Limit — Deviations from Classical Gravity

When quantum coherence dominates — in systems where quantum states are correlated rather than random — the quantum inconsistencies do not cancel. They align.

In a coherent quantum system, the quantum state contributions $\nabla_5 V_{QSF}|_{\hat{Q}_i}$ point in correlated directions in the fifth dimension. Their sum is non-zero:

$$\sum_{i=1}^{N} \nabla_5 V_{QSF}\big|_{\hat{Q}_i} \neq 0 \quad \text{for coherent quantum systems}$$

The result is a net QSF gradient with no classical equivalent — a gravitational effect produced by quantum coherence rather than mass-energy. This is the activation condition for observable deviations from classical GR. The magnitude of the deviation is expected to be extremely small except in highly engineered coherent systems or near the extreme conditions of black hole interiors and the early universe.

---

## Part VII: Negative Effective Mass

### 7.1 Prediction

If quantum properties couple to the QSF and through it to the STF, then it follows that specific quantum state configurations could produce a $T^{QSF}_{\mu\nu}(\hat{Q})$ contribution that opposes the standard gravitational contribution of $T_{\mu\nu}$.

If for some particle or composite system in quantum state $|\psi\rangle$:

$$T^{QSF}_{\mu\nu}(\hat{Q}) + T_{\mu\nu} < 0$$

Then that system has negative effective gravitational mass — it curves spacetime upward rather than downward.

### 7.2 Physical Meaning

Negative effective mass does not mean negative rest mass. It means that the quantum state contribution to the QSF potential opposes and potentially exceeds the mass-energy contribution. The particle still has positive rest mass. But its total effect on spacetime curvature — its total contribution to the consistency functional — is repulsive rather than attractive.

From the consistency perspective: certain quantum state configurations are more consistent with a locally flat or diverging spacetime than with a converging one. The QSF, enforcing consistency, generates a gradient that drives spacetime to curve away from a mass rather than toward it.

### 7.3 Implications

Negative effective mass is the theoretical requirement for:
- Alcubierre warp drive geometries
- Traversable wormhole stabilisation
- Exotic matter in general

This framework suggests these are achievable not through hypothetical exotic matter but through the manipulation of quantum states of normal matter to achieve a net negative QSF coupling.

### 7.4 Identifying the Relevant Quantum States

The quantum state $|\psi\rangle$ that produces negative effective mass must satisfy:

$$\langle \psi | T^{QSF}_{\mu\nu}(\hat{Q}) | \psi \rangle < -T_{\mu\nu}$$

Identifying which combinations of spin, charge, isospin, and other quantum numbers satisfy this inequality requires the explicit form of $T^{QSF}_{\mu\nu}(\hat{Q})$, which is the central unsolved equation.

---

## Part VIII: The Black Hole Interior Model

### 8.1 The Singularity Problem

Standard GR predicts that gravitational collapse beyond the neutron star threshold produces a singularity — a point of infinite density and infinite spacetime curvature. The singularity is universally regarded as a failure of the equations rather than a physical reality. It is the most prominent place where GR must be replaced by a more complete theory.

In the QSF framework the singularity is understood as the point at which the classical Einstein equations produce an inconsistency with no resolution — infinite density, infinite curvature — because they lack the Planck scale floor and the quantum state coupling that the full QSF theory provides. The QSF always has a finite resolution to any inconsistency. There is no configuration of matter and spacetime that the consistency functional cannot handle. Therefore there are no true singularities.

### 8.2 The Proposed Interior Structure

This framework proposes that black hole interiors are not singularities but are composed of zero-gap top quark matter — the densest physically realisable state of matter.

**The formation mechanism:**
During gravitational collapse, infalling matter is accelerated to relativistic velocities. The kinetic energy available per infalling particle approaches:

$$E_{infall} \sim 10^{20} \text{ to } 10^{21} \text{ eV}$$

The energy threshold for top quark pair production is:

$$E_{top} = 2m_t c^2 \approx 346 \text{ GeV} \approx 3.46 \times 10^{11} \text{ eV}$$

The available energy exceeds the top quark production threshold by approximately $10^9$ times. Top quark production during gravitational collapse is therefore energetically permitted.

Top quarks produced in normal spacetime decay in $5 \times 10^{-25}$ seconds. However, extreme gravitational time dilation near the event horizon stretches this decay timescale by the time dilation ratio, making the interior appear stable from outside.

### 8.3 The Maximum Density Constant

The maximum physically achievable density in this framework is determined by packing the heaviest known quark (top quark) into the minimum possible volume (one Planck volume per quark, the QSF floor):

$$\rho_{max} = \frac{m_{top}}{V_{Planck}}$$

$$V_{Planck} = \frac{4}{3}\pi l_p^3$$

$$\rho_{max} = \frac{m_{top}}{\frac{4}{3}\pi l_p^3}$$

Where:
- $m_{top} = 172.69 \text{ GeV}/c^2 = 3.0785 \times 10^{-25} \text{ kg}$
- $l_p = 1.616255 \times 10^{-35} \text{ m}$ (Planck length)

$$\boxed{\rho_{max} = 1.7406759279832146302237237994679622302159 \times 10^{79} \text{ kg/m}^3}$$

This is a universal constant. It does not depend on black hole mass. It is the density of the interior of every black hole regardless of size.

### 8.4 The Interior Radius Formula

Given the maximum density constant, the physical interior radius of any black hole of mass $M$ is:

$$r_{interior} = \left(\frac{3M}{4\pi \rho_{max}}\right)^{1/3}$$

This gives the first finite, physically motivated formula for the actual size of a black hole interior. Selected values:

| Black Hole | Mass | Interior Radius |
|---|---|---|
| Stellar (10 solar masses) | $1.989 \times 10^{31}$ kg | $6.485 \times 10^{-17}$ m (0.065 femtometers) |
| Intermediate (1,000 solar masses) | $1.989 \times 10^{33}$ kg | $3.010 \times 10^{-16}$ m (0.301 femtometers) |
| Sagittarius A* (4M solar masses) | $7.956 \times 10^{36}$ kg | $4.778 \times 10^{-15}$ m (4.778 femtometers) |
| M87 (6.5B solar masses) | $1.293 \times 10^{40}$ kg | $5.618 \times 10^{-14}$ m (56.18 femtometers) |
| Ton 618 (66B solar masses) | $1.313 \times 10^{41}$ kg | $1.217 \times 10^{-13}$ m (121.7 femtometers) |

### 8.5 The Maximum Time Dilation Constant

Standard GR predicts infinite time dilation at the singularity. This framework replaces the singularity with finite density matter at a minimum radius set by the Planck scale. The maximum time dilation ratio is therefore finite:

$$N = \sqrt{\frac{r_s}{l_p}} = \sqrt{\frac{2GM}{c^2 l_p}}$$

This gives each black hole a unique, finite, calculable maximum time dilation constant. Selected values:

| Black Hole | Maximum Time Dilation N | 1 second inside = |
|---|---|---|
| Stellar (10 solar masses) | $4.275 \times 10^{19}$ | 1.355 trillion years |
| Sagittarius A* | $2.704 \times 10^{22}$ | 856 trillion years |
| M87 | $1.090 \times 10^{24}$ | 34.5 quadrillion years |
| Ton 618 | $3.473 \times 10^{24}$ | 110 quadrillion years |

The universe does not produce infinite time dilation. It produces very large finite numbers bounded by the Planck scale.

### 8.6 Hawking Radiation — Physical Mechanism

Standard Hawking radiation theory explains mass loss through virtual particle pair production at the event horizon — a quantum bookkeeping argument with no explicit physical mechanism for the interior mass loss.

This framework provides the physical mechanism:

**The time-dilated decay model:**
Top quarks in the interior decay constantly as seen by an interior observer. This decay is time-dilated by factor $N$ as seen by an exterior observer. The decay products eventually escape or contribute to the mass-energy budget of the outgoing radiation.

**Decay chain:**
$$t \rightarrow W^+ + b \rightarrow e^+/\mu^+/\nu + \bar{\nu} + b$$

The decay products include photons, electrons, positrons, and neutrinos — consistent with the predicted thermal spectrum of Hawking radiation.

**The acceleration mechanism:**
As the black hole loses mass:
- The Schwarzschild radius $r_s$ decreases
- The time dilation ratio $N = \sqrt{r_s/l_p}$ decreases
- The apparent decay rate of interior top quarks increases
- Mass loss accelerates
- This produces the runaway evaporation predicted by Hawking's equations, but with a physical mechanism

**The final explosion:**
As the black hole approaches its final moments, $N$ approaches 1. The time dilation suppression of top quark decay disappears. The remaining mass decays at or near the natural timescale. The energy release follows:

$$E_{final} = M_{remaining} c^2$$

This produces the gamma ray burst predicted in the final moments of black hole evaporation.

### 8.7 The Information Paradox

In this framework, information is not destroyed but is rendered practically irrecoverable through an extreme scrambling process:

1. Infalling matter is decomposed to fundamental particles
2. Fundamental particles are converted to top quarks via high-energy QCD processes
3. Top quarks decay across billions of time-dilated years
4. Decay products emerge as featureless thermal Hawking radiation
5. Information is encoded in the precise quantum correlations of all emitted radiation across the entire evaporation lifetime of the black hole

Information is technically conserved (consistent with quantum mechanical unitarity) but is distributed across cosmological timescales of Hawking radiation in a thermal spectrum. Recovery would require perfect knowledge of every emitted particle across the entire evaporation history.

---

## Part IX: What the ToE Must Reproduce

For this framework to be considered a valid Theory of Everything, the formal mathematical development must reproduce the following from the QSF equations alone:

### 9.1 From General Relativity

- Einstein Field Equations in the low quantum-correction limit
- Schwarzschild metric for spherically symmetric mass
- Kerr metric for rotating black holes
- Gravitational wave solutions
- Cosmological expansion (FLRW metric)
- Gravitational lensing
- Perihelion precession of Mercury
- Frame dragging (Lense-Thirring effect)

### 9.2 From Quantum Field Theory and the Standard Model

- Klein-Gordon equation for scalar fields
- Dirac equation for fermions
- Maxwell equations for electromagnetism
- Yang-Mills equations for non-abelian gauge theories
- Higgs mechanism and mass generation
- All Standard Model particle masses and coupling constants
- Running of coupling constants with energy scale
- CKM and PMNS mixing matrices

### 9.3 From Classical Physics

- Newtonian gravity in the weak field, low velocity limit
- Conservation of energy, momentum, and angular momentum
- Laws of thermodynamics including black hole thermodynamics

---

## Part X: Testable Predictions

### 10.1 Spin-Induced Gravitational Signature

If quantum spin couples to the QSF and through it to the STF, then flipping the spin state of a macroscopic ensemble of particles should produce a measurable change in local gravitational field strength.

**Prediction:** A spin-polarised ensemble of particles in state $|+\rangle$ will have a measurably different local gravitational signature than the same ensemble in state $|-\rangle$.

**Order of magnitude estimate:** The effect is expected to be many orders of magnitude below current measurement sensitivity but defines a target for future gravitational wave detector sensitivity.

### 10.2 Entanglement Gravitational Correlation

If entanglement state couples to the QSF, then entangled particle pairs will have correlated gravitational signatures that cannot be explained by their individual mass-energy content alone.

**Prediction:** A pair of maximally entangled particles will exhibit gravitational correlations beyond those predicted by GR alone.

### 10.3 Black Hole Evaporation Spectrum Deviation

If Hawking radiation arises from time-dilated top quark decay rather than virtual pair production, the radiation spectrum should contain signatures of the top quark decay chain — specifically a non-thermal component at energies corresponding to W boson and bottom quark decay products.

**Prediction:** The Hawking radiation spectrum deviates from a perfect blackbody spectrum at energies corresponding to top quark decay products.

### 10.4 Minimum Black Hole Mass

The interior density constant $\rho_{max}$ implies a minimum black hole mass — the mass of a black hole whose Schwarzschild radius equals its interior radius:

$$r_s = r_{interior}$$
$$\frac{2GM_{min}}{c^2} = \left(\frac{3M_{min}}{4\pi\rho_{max}}\right)^{1/3}$$

Solving for $M_{min}$ gives the minimum possible black hole mass in this framework. Below this mass, the object cannot form a black hole because the Schwarzschild radius would be smaller than the physical interior.

### 10.5 Negative Effective Mass Threshold

For specific quantum state configurations, there exists a threshold at which the quantum state contribution to the QSF potential exceeds the mass-energy contribution, producing net gravitational repulsion.

**Prediction:** There exists at least one quantum state $|\psi\rangle$ of a known particle or composite system for which the local gravitational effect is repulsive.

### 10.6 Coherence-Dependent Gravity

In the macroscopic limit, the QSF predicts exact recovery of classical GR because random quantum states produce cancelling QSF gradients. In the quantum coherent limit, the QSF predicts deviations from classical GR proportional to the degree of quantum coherence.

**Prediction:** Sufficiently large, sufficiently coherent quantum systems will exhibit measurable gravitational anomalies — deviations from GR-predicted behaviour — that scale with the coherence length and coherence time of the system. This provides a new class of experiments at the intersection of quantum information science and gravitational physics.

---

## Part X.5: The Curvature-Following Principle

### The Geometry of Gravity

A persistent conceptual risk in any theory that invokes a "fifth-dimensional force" is the implication that particles are being pushed by something external — that some new energy source or external agent is required to produce gravitational motion, and that this might violate conservation of energy or momentum.

This framework carries no such implication. The QSF does not push particles. It defines geometry. The distinction is fundamental:

**In General Relativity:**
A planet orbiting a star is not being pulled by a gravitational force. It is following the straightest possible path — a geodesic — through the curved four-dimensional spacetime geometry produced by the star's mass. No force acts. No energy is injected. The planet follows the shape of spacetime because that is what objects do when no force acts on them.

**In the QSF framework:**
The same principle is extended by one dimension. A particle following the QSF potential gradient toward the local minimum is not being pushed. It is following the straightest possible path through the curved five-dimensional geometry of the QSF. No force acts in the Newtonian sense. No energy is injected. The particle follows the shape of the fifth dimension because that is what particles do when no force acts on them in five-dimensional QSF spacetime.

The equation:

$$\vec{F}_{QSF} = -\nabla_5 V_{QSF}$$

uses the language of force because it is the most compact mathematical expression for the gradient of the potential. But its physical content is geometric: $\nabla_5 V_{QSF}$ is the slope of the fifth-dimensional curvature landscape at a given point. Particles slide along this slope not because they are compelled, but because the slope is the shape of space itself.

**Conservation laws are automatically satisfied** because:
1. The QSF gradient is conservative — the work done by following the gradient around a closed loop is zero, exactly as in all geometric theories of gravity.
2. The 5D geodesic equation preserves the analogues of energy and momentum in five dimensions, which project onto the preserved energy and momentum of four-dimensional GR.
3. No external agent is required and no hidden energy reservoir is being depleted. The QSF potential landscape is a property of the geometry, not a stored energy to be consumed.

This principle unifies the QSF theory with the deepest insight of GR: that what we call gravity is not a force at all, but the geometry of the space particles live in. QSF extends this from four dimensions to five, and from the geometry of mass-energy alone to the geometry determined by the complete quantum state of matter.

---

## Part XI: The Governing Principle

### 11.1 The Consistency Optimisation Principle

All dynamics in the QSF framework follow from a single governing principle:

> **The Quantum Space Field evolves so as to continuously minimise inconsistency between the global quantum state of all matter and the geometric structure of spacetime.**

This is the Consistency Optimisation Principle. It is not an axiom imposed from outside. It is the inevitable behaviour of any mediating field that couples bidirectionally to both a quantum layer and a geometric layer: any mismatch between the two states generates a gradient, and the gradient drives motion that reduces the mismatch. The principle is self-enforcing.

### 11.2 Formal Statement

Let $\hat{Q}$ denote the global quantum configuration — the complete quantum state of all matter fields — and let $g_{\mu\nu}$ denote the spacetime metric encoding the geometric structure of reality. Define the consistency functional:

$$\mathcal{I}[\,g_{\mu\nu},\ \hat{Q}\,]$$

as a measure of the degree of mismatch between these two configurations. The QSF potential is this functional:

$$V_{QSF}(g_{\mu\nu}, \hat{Q}) = \mathcal{I}[\,g_{\mu\nu},\ \hat{Q}\,]$$

The governing principle states:

$$\frac{\delta \mathcal{I}}{\delta t} \leq 0$$

The consistency functional is non-increasing in time. The universe evolves in a direction of decreasing inconsistency. Stable configurations are those for which the functional is locally minimised.

The gradient of this functional in the fifth dimension is:

$$\nabla_5 \mathcal{I} = \nabla_5 V_{QSF}$$

And the force law is:

$$\vec{F}_{QSF} = -\nabla_5 \mathcal{I}[\,g_{\mu\nu},\ \hat{Q}\,]$$

### 11.3 How Inconsistency Manifests

A mismatch between quantum state and spacetime geometry does not remain as an abstract discrepancy. It has a physical signature:

- It manifests as curvature in the fifth dimension of the QSF
- This curvature produces a gradient — the QSF force
- The gradient drives particle motion in four-dimensional spacetime
- Particle motion modifies the quantum state $\hat{Q}$ and, through the modified Einstein equations, the metric $g_{\mu\nu}$
- The new configuration is more consistent than the old

The cycle is:

$$\text{Inconsistency} \rightarrow \text{5D curvature} \rightarrow \text{QSF gradient} \rightarrow \text{particle motion} \rightarrow \text{reduced inconsistency}$$

This cycle is what physics calls gravity.

### 11.4 Stable Configurations

A stable physical configuration — a bound orbit, an atomic ground state, a solid at rest — is one in which the consistency functional is locally minimised. The quantum state and the spacetime geometry are, at that configuration, in their most mutually consistent arrangement. No net QSF gradient remains to drive further motion.

This provides a physical interpretation of stability that unifies all of physics:
- The ground state of an atom is the configuration of maximum quantum-geometric consistency for that electron-nucleus system
- A planetary orbit is the trajectory of maximum consistency between the planet's quantum state and the Sun's gravitational geometry
- The stable matter content of the universe is the set of QSF crystallisations that are consistent with the current cosmological spacetime geometry

### 11.5 Macroscopic Suppression

In macroscopic systems, individual particles carry random, uncorrelated quantum states. Their contributions to the consistency functional sum incoherently:

$$\mathcal{I}[\,g_{\mu\nu},\ \hat{Q}_{macro}\,] \approx \mathcal{I}[\,g_{\mu\nu},\ T_{\mu\nu}\,]$$

That is: the consistency functional for a macroscopic incoherent system reduces to a function of the classical stress-energy tensor alone. The quantum correction terms average to zero. The QSF gradient is determined entirely by mass-energy distribution.

The result is exact recovery of classical General Relativity. No correction term is observable. No new force appears. The macroscopic universe behaves exactly as GR predicts because GR is the statistical limit of the Consistency Optimisation Principle applied to incoherent matter.

### 11.6 Quantum Coherence Activation

When quantum coherence is present — when particles share a correlated quantum state — the contributions to the consistency functional no longer cancel. They reinforce:

$$\mathcal{I}[\,g_{\mu\nu},\ \hat{Q}_{coherent}\,] \neq \mathcal{I}[\,g_{\mu\nu},\ T_{\mu\nu}\,]$$

The quantum correction term $T^{QSF}_{\mu\nu}(\hat{Q})$ contributes a non-zero residual. The QSF gradient has a component not present in classical GR. Observable deviations from classical gravity become possible.

The activation condition is quantum coherence. The magnitude of the deviation scales with the degree of coherence and the number of coherently correlated particles.

### 11.7 The Governing Principle as the Foundation of the Axiom Set

The ten axioms stated in Part XII are not independent postulates — they are consequences of the Consistency Optimisation Principle applied to the three-layer architecture:

- The three-layer architecture exists because two incompatible frameworks require a mediating layer that speaks both languages and enforces consistency between them
- QSF flatness exists because the consistency-enforcing layer must be stable in order to do its job — a dynamically fluctuating mediator cannot enforce consistency
- The fifth dimension exists because the consistency enforcement must have a degree of freedom not already occupied by the four-dimensional geometry — it needs a direction to act in
- Bidirectional coupling exists because consistency enforcement necessarily operates in both directions — neither the quantum state nor the geometry can be the sole ground truth
- Complete quantum coupling exists because consistency between quantum state and geometry requires accounting for the full quantum state, not just its mass-energy projection
- Gravitons as QSF excitations follows because the carrier of the consistency signal must be a QSF entity
- The Planck scale floor follows because the consistency functional must remain finite and well-defined everywhere — infinite density is an inconsistency with no finite resolution, and the QSF cannot produce that
- Maximum density follows from the Planck scale floor
- The principle of least action follows because the path of least action is identically the path of greatest consistency gain per unit time
- No singularities follow because the consistency functional has no infinite values

The governing principle is prior to all axioms. It is the single physical idea from which the entire framework is derived.

---

## Part XII: Open Problems

The following are the primary unsolved problems that formal mathematical development must address:

### 12.1 The QSF Field Equation

What equation governs the intrinsic dynamics of the QSF itself? What type of field is it — scalar, vector, tensor, spinor, or something new? What are its symmetries and transformation properties under the Lorentz group and general coordinate transformations?

### 12.2 The Quantum-Gravity Coupling Function

The explicit form of $T^{QSF}_{\mu\nu}(\hat{Q})$ must be derived from first principles. This requires determining the coupling constants between each quantum property (spin, charge, isospin, colour charge, phase, entanglement) and the QSF potential.

### 12.3 The Consistency Functional

The explicit form of $\mathcal{I}[g_{\mu\nu}, \hat{Q}]$ must be derived. This is the most fundamental unsolved problem. It is equivalent to finding the functional form of $f$ in:

$$\nabla_5 V_{QSF} = f(T_{\mu\nu}, \hat{Q})$$

The consistency functional is the mathematical heart of the theory. Every other equation is a consequence of its form.

### 12.4 The Fifth Dimension Geometry

The precise geometric nature of the fifth dimension must be characterised. Is it compact? If so, what is its compactification radius? What is its topology? How does it interact with the four macroscopic dimensions under extreme conditions such as inside a black hole?

### 12.5 Top Quark Formation in Collapse

A rigorous mechanism must be established for why gravitational collapse specifically produces top quarks rather than the strange quark matter predicted by current models. The energy argument is qualitatively sufficient but quantitative derivation is required.

### 12.6 QSF Renormalisability Proof

It must be formally demonstrated that quantising gravity as QSF excitations (gravitons) on the flat QSF background is indeed renormalisable — that the infinities that plague conventional quantum gravity approaches do not appear in the QSF framework.

### 12.7 Standard Model Emergence

It must be demonstrated that the Standard Model particle content — all 12 fermions, all force carriers, the Higgs boson — emerges naturally from the QSF equations without being put in by hand.

### 12.8 Derivation of the Consistency Optimisation Principle

The governing principle must be derived from a more fundamental variational principle rather than stated as a physical postulate. The natural candidate is a five-dimensional action principle whose stationary points correspond to consistency-minimising configurations:

$$\delta S_{5D} = \delta \int d^5x\ \sqrt{-g_5}\ \mathcal{L}_{QSF}(g_{\mu\nu}, \hat{Q}, \partial_5 \Phi) = 0$$

Where $g_5$ is the five-dimensional metric determinant and $\mathcal{L}_{QSF}$ is the QSF Lagrangian density. The derivation of this Lagrangian is an open problem.

---

## Part XIII: Summary of Core Axioms

The framework rests on the following foundational axioms, each of which is a consequence of the Consistency Optimisation Principle applied to the three-layer architecture:

**Axiom 1 — Three Layer Architecture:**
Reality consists of three fundamental layers: the Spacetime Fabric (STF), the Quantum Space Field (QSF), and the Quantum Fields (QF). All interactions between STF and QF are mediated by the QSF.

**Axiom 2 — QSF Flatness:**
The QSF is flat and static from the perspective of the Quantum Fields. This is not an approximation. It is an exact property of the QSF layer.

**Axiom 3 — Fifth Dimension:**
The QSF extends into a fifth dimension. The force it exerts on particles is directed along this fifth dimension toward the local potential minimum — that is, toward the configuration of maximum quantum-geometric consistency.

**Axiom 4 — Bidirectional Coupling:**
The coupling between all three layers is bidirectional. STF geometry modifies the QSF potential. QSF potential gradients exert forces on QF excitations. QF quantum states modify the QSF potential. Modified QSF potential modifies STF geometry.

**Axiom 5 — Complete Quantum Coupling:**
All quantum properties of matter — not just mass-energy — couple to the QSF and through it to the STF. The stress-energy tensor of GR is incomplete. The full gravitational source includes quantum state contributions.

**Axiom 6 — Gravitons as QSF Excitations:**
Gravitons are excitations of the QSF. They propagate on the flat QSF background. They are the carrier particles of the fifth-dimensional force that manifests as gravity in four dimensions.

**Axiom 7 — Planck Scale Floor:**
The Planck length $l_p = 1.616255 \times 10^{-35}$ m is the minimum physically meaningful length scale. Spacetime is not continuous below this scale. This floor eliminates all singularities by replacing infinite density with the finite maximum density constant $\rho_{max}$.

**Axiom 8 — Maximum Density:**
The maximum physically achievable density in the universe is:
$$\rho_{max} = \frac{m_{top}}{V_{Planck}} = 1.7406759279832146 \times 10^{79} \text{ kg/m}^3$$

**Axiom 9 — Principle of Least Action as QSF Consistency Gradient:**
The principle of least action is not a fundamental axiom of nature. It is a derived consequence of the geometry of the QSF fifth dimension. All physical systems follow the local gradient of $V_{QSF}$ — the consistency functional — toward the potential minimum. The path of least action is the path of greatest consistency gain. Motion along this path is free motion along the curvature of the fifth dimension. It violates no conservation law and requires no energy input.

**Axiom 10 — No Singularities:**
True mathematical singularities do not exist in physical reality. Every apparent singularity in GR is a failure of the equations when applied beyond their domain of validity. The QSF framework with its Planck scale floor and finite consistency functional produces finite values everywhere.

**Axiom 11 — Consistency Optimisation:**
The QSF evolves so as to minimise the inconsistency between the global quantum state $\hat{Q}$ and the spacetime geometry $g_{\mu\nu}$. This is the governing principle from which all other axioms and all dynamics are derived. It is not an additional assumption — it is the single physical statement that the QSF framework is built to express.

---

## Appendix A: Key Constants

| Constant | Symbol | Value |
|---|---|---|
| Speed of light | $c$ | $299792458$ m/s |
| Gravitational constant | $G$ | $6.67430 \times 10^{-11}$ m³/kg/s² |
| Planck constant (reduced) | $\hbar$ | $1.054571817 \times 10^{-34}$ J·s |
| Planck length | $l_p$ | $1.616255 \times 10^{-35}$ m |
| Boltzmann constant | $k_B$ | $1.380649 \times 10^{-23}$ J/K |
| Top quark mass | $m_t$ | $172.69$ GeV/$c^2$ |
| Solar mass | $M_\odot$ | $1.98892 \times 10^{30}$ kg |
| Maximum density constant | $\rho_{max}$ | $1.7406759279832146 \times 10^{79}$ kg/m³ |

---

## Appendix B: Key Equations

**Modified Einstein Field Equations:**
$$G_{\mu\nu} + \Lambda g_{\mu\nu} = \frac{8\pi G}{c^4}\left(T_{\mu\nu} + T^{QSF}_{\mu\nu}(\hat{Q})\right)$$

**QSF Force Law (Consistency Gradient):**
$$\vec{F}_{QSF} = -\nabla_5 V_{QSF}(g_{\mu\nu}, \hat{Q}) = -\nabla_5 \mathcal{I}[\,g_{\mu\nu},\ \hat{Q}\,]$$

**Five-Dimensional Geodesic Equation (placeholder form):**
$$\frac{d^2x^A}{d\tau^2} + \Gamma^A_{BC}\frac{dx^B}{d\tau}\frac{dx^C}{d\tau} = 0, \quad A, B, C \in \{0,1,2,3,5\}$$

**QSF Potential Decomposition:**
$$V_{QSF}(g_{\mu\nu}, \hat{Q}) = V_{classical}(g_{\mu\nu}) + V_{quantum}(\hat{Q}) + V_{coupling}(g_{\mu\nu}, \hat{Q})$$

**Macroscopic Limit (Classical Gravity Recovery):**
$$\lim_{N \to \infty,\ \text{incoherent}} T^{QSF}_{\mu\nu}(\hat{Q}) = 0 \quad \Rightarrow \quad G_{\mu\nu} + \Lambda g_{\mu\nu} = \frac{8\pi G}{c^4} T_{\mu\nu}$$

**Quantum Coherence Correction:**
$$\delta G_{\mu\nu} = \frac{8\pi G}{c^4} T^{QSF}_{\mu\nu}(\hat{Q}_{coherent}) \neq 0$$

**Maximum Density Constant:**
$$\rho_{max} = \frac{m_{top}}{\frac{4}{3}\pi l_p^3}$$

**Black Hole Interior Radius:**
$$r_{interior} = \left(\frac{3M}{4\pi\rho_{max}}\right)^{1/3}$$

**Maximum Time Dilation:**
$$N = \sqrt{\frac{r_s}{l_p}} = \sqrt{\frac{2GM}{c^2 l_p}}$$

**Hawking Temperature (standard, to be derived from QSF):**
$$T_H = \frac{\hbar c^3}{8\pi G M k_B}$$

**Consistency Functional Governing Equation (placeholder):**
$$\frac{\delta \mathcal{I}[\,g_{\mu\nu},\ \hat{Q}\,]}{\delta t} \leq 0$$

---

## Closing Statement

This framework is incomplete. The central equations are sketched but not derived. The consistency functional is identified but not calculated. The emergence of GR and the Standard Model from QSF dynamics has not been demonstrated.

What this document contains is a physical picture of reality that is internally consistent at every level. It addresses every major incompatibility between GR and QFT. It gives gravitons a well-defined home. It mechanically explains the principle of least action. It eliminates singularities. It provides finite calculable black hole interior properties. It makes in-principle testable predictions. And it does all of this from a single governing principle: the universe enforces consistency between its quantum and geometric degrees of freedom, and what we call gravity is the observable four-dimensional shadow of that enforcement process.

A recurring concern with any new gravitational theory is whether it introduces forces that violate conservation laws or require new energy sources. This framework does not. Every particle interaction attributed to the QSF gradient is an instance of an object following curvature — the curvature of the fifth dimension — in exactly the same sense that GR particles follow the curvature of four-dimensional spacetime. Curvature-following is inherently conservative. It requires no external energy, produces no violations of momentum or angular momentum conservation, and is consistent with every established physical law. The QSF framework does not break physics. It extends the geometry by one dimension and gives that extension a physical meaning: the fifth dimension is the degree of freedom in which the universe resolves the inconsistency between what matter is doing quantum mechanically and what spacetime is doing geometrically.

There are no remaining internal contradictions. The macroscopic limit recovers GR exactly. The quantum coherent limit predicts testable deviations. The Planck scale floor eliminates all singularities. The bidirectional coupling ensures neither quantum state nor spacetime geometry is privileged — they are co-equal aspects of a single self-consistent structure, and the QSF is the mechanism that keeps them so.

The mathematics required to complete this framework is the mathematics of a new kind of field theory — one that is simultaneously geometric and quantum, operates across five dimensions, has bidirectional coupling between all its layers, and is governed by a consistency functional whose extremisation reproduces all of known physics. That mathematics may require new tools that do not yet exist.

The picture came first. The mathematics follows the picture.

That is how physics has always worked.
