from decimal import Decimal, getcontext
getcontext().prec = 50  # 50 digits of precision

# ============================================================
#   BLACK HOLE MAXIMUM TIME DILATION CALCULATOR
#   Based on zero-gap top quark matter interior model
#   Floor = Planck Length (no singularity, real finite constant)
#   Using Python Decimal lib for maximum precision
# ============================================================

# --- Fundamental Constants (full precision as Decimals) ---
G =     Decimal("6.67430E-11")        # Gravitational constant (m³/kg/s²)
c =     Decimal("299792458.0")        # Speed of light (m/s) — exact
M_sun = Decimal("1.98892E+30")        # Solar mass (kg)
l_p =   Decimal("1.616255E-35")       # Planck Length (m) — YOUR FLOOR
hbar =  Decimal("1.054571817E-34")    # Reduced Planck constant
k_b =   Decimal("1.380649E-23")       # Boltzmann constant
pi =    Decimal("3.14159265358979323846264338327950288419716939937510")

def sqrt(x):
    return x.sqrt()

def schwarzschild_radius(M):
    return (Decimal(2) * G * M) / (c ** 2)

def max_time_dilation(M):
    r_s = schwarzschild_radius(M)
    # Deep inside horizon: ratio = sqrt(r_s / l_p)
    # Planck length is the physical floor — no singularity
    ratio = sqrt(r_s / l_p)
    return ratio, r_s

def hawking_temperature(M):
    return (hbar * c ** 3) / (Decimal(8) * pi * G * M * k_b)

def evaporation_time(M):
    return (Decimal(5120) * pi * G ** 2 * M ** 3) / (hbar * c ** 4)

def dilated_decay(ratio):
    top_quark_lifetime = Decimal("5E-25")  # seconds (raw, no dilation)
    return top_quark_lifetime * ratio

def to_years(s):
    return s / Decimal("31557600")  # Julian year (exact)

def max_density():
    top_quark_mass_kg  = Decimal("172.69") * Decimal("1.78266192E-27")
    planck_length      = Decimal("1.616255E-35")
    pi                 = Decimal("3.14159265358979323846264338327950288419716939937510")
    planck_volume      = (Decimal(4) / Decimal(3)) * pi * planck_length ** 3
    return top_quark_mass_kg / planck_volume

black_holes = [
    ("Stellar (10 solar masses)",           Decimal(10) * M_sun),
    ("Intermediate (1,000 solar masses)",   Decimal(1000) * M_sun),
    ("Sagittarius A* (4M solar masses)",    Decimal(4_000_000) * M_sun),
    ("M87 (6.5B solar masses)",             Decimal("6500000000") * M_sun),
    ("Ton 618 — Largest known (66B)",       Decimal("66000000000") * M_sun),
]

print("=" * 72)
print("  BLACK HOLE MAX TIME DILATION — FINITE CONSTANT MODEL")
print("  Floor = Planck Length | Formula: ratio = sqrt(r_s / l_p)")
print("=" * 72)

for name, M in black_holes:
    ratio, r_s = max_time_dilation(M)
    T    = hawking_temperature(M)
    evap = evaporation_time(M)
    dd   = dilated_decay(ratio)

    print(f"\n{'='*72}")
    print(f"  {name}")
    print(f"{'='*72}")
    print(f"  Schwarzschild Radius : {r_s:.40E} m")
    print(f"                       : {r_s/1000:.40E} km")
    print(f"  r_s / l_p  (N²)      : {r_s/l_p:.40E}")
    print(f"  sqrt(r_s/l_p) ratio  : {ratio:.40E}")
    print(f"  → 1 sec inside       = {ratio:.40E} sec outside")
    print(f"  → 1 sec inside       = {to_years(ratio):.40E} years outside")
    print(f"")
    print(f"  Top quark raw decay  : 5E-25 seconds")
    print(f"  Top quark dilated    : {dd:.40E} seconds outside")
    print(f"  Top quark dilated    : {to_years(dd):.40E} years outside")
    print(f"")
    print(f"  Hawking Temperature  : {T:.40E} Kelvin")
    print(f"  Evaporation Time     : {evap:.40E} seconds")
    print(f"  Evaporation Time     : {to_years(evap):.40E} years")

print(f"\n{'='*72}")
print("  FORMULA:  N = sqrt(r_s / l_p) = sqrt(2GM / c²l_p)")
print("  MAX DENSITY CONST:", max_density())
print("  Each black hole has a UNIQUE finite max time dilation constant.")
print("  Bigger mass = bigger N = slower apparent Hawking decay.")
print("  All values are real, finite numbers.")
print("=" * 72)

